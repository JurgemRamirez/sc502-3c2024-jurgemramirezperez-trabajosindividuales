function cambioContenido() {
    var parrafo = document.getElementById("contenido");
    parrafo.innerHTML = "El contenido cambio ";
}
